const http = require('http');
const app = require('./app');
const server = http.createServer(app);

server.listen(3310,()=>{
    console.log("Server Listning on PORT 3310");
})